package com.yue.androidtweets

import android.net.UrlQuerySanitizer

data class Tweet constructor(
    val name: String,
    val handle: String,
    val content: String,
    val iconUrl:String)