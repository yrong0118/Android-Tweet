package com.yue.androidtweets

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TweetsActivity : AppCompatActivity(){

    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tweets)

        // getStringExtra retrieves the value associated with the key "LOCATION", casting it to a String
        // If the key does not exist in the Intent, null will be returned, so you may also want to use
        // hasExtra(...) to check if your key is in the intent (if it's possible for it to be missing)
        val location: String = intent.getStringExtra("LOCATION")

        // This is a combination of two Kotlin shorthands:
        //   1. setTitle("...")
        //   2. "Android Tweets near " + location

        title = getString(R.string.tweets_title, location)
        //title = "Android Tweets near $location"
        //        setTitle("Android Tweets near" + location)
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}

