package com.yue.androidtweets

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class TweetsAdapter: RecyclerView.Adapter <TweetsAdapter.TweetsViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TweetsViewHolder {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun getItemCount(): Int {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onBindViewHolder(holder: TweetsViewHolder, position: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    class TweetsViewHolder(view: View) : RecyclerView.ViewHolder(view){

    }
}